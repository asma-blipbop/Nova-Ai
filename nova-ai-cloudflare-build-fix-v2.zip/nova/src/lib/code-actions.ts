import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import Anthropic from '@anthropic-ai/sdk'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'
import { spendCredits, getBalance, InsufficientCreditsError } from './credits.js'

const CODE_COST_CREDITS = 3

const PROMPTS: Record<string, string> = {
  generate: 'Génère le code demandé selon ces instructions.',
  fix: 'Corrige les bugs dans ce code.',
  explain: 'Explique ce que fait ce code, ligne par ligne si utile.',
  refactor: 'Refactorise ce code pour le rendre plus lisible et maintenable, sans changer son comportement.',
  optimize: 'Optimise les performances de ce code sans changer son comportement.',
}

export const runCodeAssistant = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(
    z.object({
      action: z.enum(['generate', 'fix', 'explain', 'refactor', 'optimize']),
      code: z.string().max(20000),
      instructions: z.string().max(2000),
    }),
  )
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context!.user)
    const { available } = await getBalance(localUser.id)
    if (available < CODE_COST_CREDITS) throw new InsufficientCreditsError()

    const anthropic = new Anthropic()
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-5',
      max_tokens: 2048,
      messages: [
        {
          role: 'user',
          content: `${PROMPTS[data.action]}\n\nInstructions: ${data.instructions || '(aucune)'}\n\nCode:\n${data.code || '(aucun code fourni)'}`,
        },
      ],
    })
    const block = message.content[0]
    const output = block && block.type === 'text' ? block.text : ''

    await spendCredits({
      userId: localUser.id,
      amount: CODE_COST_CREDITS,
      reason: 'code',
      idempotencyKey: `code-${localUser.id}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    })

    return { output }
  })
