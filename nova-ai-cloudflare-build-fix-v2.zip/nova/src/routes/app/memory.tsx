import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { Brain, Plus, Trash2 } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { getMyMemories, addMemory, toggleMemory, deleteMemory } from '../../lib/memory-actions'

export const Route = createFileRoute('/app/memory')({
  component: MemoryPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
  loader: () => getMyMemories(),
})

function MemoryPage() {
  const initial = Route.useLoaderData()
  const [items, setItems] = useState(initial)
  const [content, setContent] = useState('')

  async function handleAdd() {
    if (!content.trim()) return
    const memory = await addMemory({ data: { content } })
    setItems((prev) => [memory, ...prev])
    setContent('')
  }

  async function handleToggle(id: string, enabled: boolean) {
    await toggleMemory({ data: { id, enabled } })
    setItems((prev) => prev.map((m) => (m.id === id ? { ...m, enabled } : m)))
  }

  async function handleDelete(id: string) {
    await deleteMemory({ data: { id } })
    setItems((prev) => prev.filter((m) => m.id !== id))
  }

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Brain size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">Mémoire</h1>
        </div>
        <p className="text-sm text-nova-text-dim mb-6">
          Ce que NOVA AI retient de toi. Ajoute, désactive ou supprime librement chaque élément.
        </p>
        <div className="flex gap-2 mb-6">
          <input
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Ex: je préfère les réponses courtes"
            className="flex-1 bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm"
          />
          <button onClick={handleAdd} className="nova-btn-primary rounded-lg px-4"><Plus size={16} /></button>
        </div>
        <div className="space-y-2">
          {items.length === 0 && <p className="text-sm text-nova-text-dim">Aucun souvenir enregistré.</p>}
          {items.map((m) => (
            <div key={m.id} className="nova-card p-4 flex items-center justify-between gap-4">
              <p className={`text-sm ${!m.enabled ? 'opacity-40 line-through' : ''}`}>{m.content}</p>
              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={() => handleToggle(m.id, !m.enabled)}
                  className={`text-xs px-2 py-1 rounded-md border ${m.enabled ? 'border-nova-violet text-nova-violet-light' : 'border-nova-border text-nova-text-dim'}`}
                >
                  {m.enabled ? 'Actif' : 'Désactivé'}
                </button>
                <button onClick={() => handleDelete(m.id)} className="text-nova-text-dim hover:text-red-400">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
