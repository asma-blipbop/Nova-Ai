# NOVA AI

**Toute l'IA. Un seul espace.**

NOVA AI est une plateforme SaaS regroupant plusieurs outils IA (vidéo, image, chat,
recherche, documents, code) derrière une identité de marque unique, un système de
crédits centralisé et une facturation Revolut Payment Links avec validation manuelle.

Ce dépôt contient le produit réel — pas une démo. Toute fonctionnalité qui dépend d'un
fournisseur tiers non configuré affiche honnêtement **"Fournisseur non configuré"**
plutôt que de simuler un résultat.

## Stack technique

- [TanStack Start](https://tanstack.com/start) (React 19 + Vite 7 + TypeScript, routing par fichiers)
- Tailwind CSS v4 (design system NOVA AI : dark premium, glassmorphism, accents violet/bleu néon)
- [Netlify Identity](https://docs.netlify.com/manage/identity/) pour l'authentification (email/mot de passe + OAuth Google)
- [Netlify Database](https://docs.netlify.com/build/data-and-storage/netlify-db/) (Postgres) + [Drizzle ORM](https://orm.drizzle.team/)
- [Netlify AI Gateway](https://docs.netlify.com/build/ai-gateway/overview/) pour les appels IA (Anthropic Claude) sans clé à configurer sur un site déployé
- Zod pour la validation des entrées des fonctions serveur

## Démarrage local

```bash
npm install
npm run dev
```

L'authentification Netlify Identity ne fonctionne que sur un déploiement Netlify réel
(pas en local). Copier `.env.example` vers `.env` pour la configuration optionnelle
(clés fournisseurs vidéo, recherche, stockage, Revolut).

## Base de données

Le schéma est défini dans `db/schema.ts`. Pour générer une nouvelle migration après une
modification du schéma :

```bash
npx drizzle-kit generate --name <nom_de_la_migration>
```

Les migrations sont stockées dans `netlify/database/migrations/` et appliquées
automatiquement au déploiement.

## Principe fondamental : ne jamais simuler

Aucune fonctionnalité de ce projet ne doit jamais afficher un résultat, un prix, un
solde de crédits ou un statut de paiement inventé. Voir `AGENTS.md` pour le détail de
comment cette règle est appliquée structurellement (ex. `listEnabledVideoModels()`,
`recordPendingPayment` / `confirmPayment`).
