import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { videoGenerations, videoJobs, videoModels } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'
import { reserveCredits, releaseReservedCredits } from './credits.js'
import { listEnabledVideoModels, submitToVideoProvider, VideoProviderNotConfiguredError } from './video-provider.js'

export const getVideoCatalog = createServerFn({ method: 'GET' }).handler(async () => {
  return listEnabledVideoModels()
})

const createVideoJobSchema = z.object({
  modelSlug: z.string(),
  mode: z.enum(['text_to_video', 'image_to_video', 'variation']),
  prompt: z.string().min(3).max(2000),
  stylePreset: z.string().optional(),
  ratio: z.string(),
  durationSeconds: z.number().int().positive(),
  cameraControls: z.record(z.string(), z.unknown()).optional(),
  sourceGenerationId: z.string().uuid().optional(),
})

/**
 * The full NOVA VIDEO pipeline entry point:
 * validate -> resolve model & cost -> reserve credits -> create job row -> call provider.
 * If the provider call fails (most commonly: not configured yet), reserved credits
 * are released immediately and the job is marked failed — never a silent fake success.
 */
export const createVideoJob = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(createVideoJobSchema)
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context!.user)

    const model = await db.query.videoModels.findFirst({ where: eq(videoModels.slug, data.modelSlug) })
    if (!model) throw new Error('Modèle vidéo introuvable')
    if (!model.supportedDurationsSeconds.includes(data.durationSeconds)) {
      throw new Error('Durée non supportée par ce modèle')
    }
    if (!model.supportedRatios.includes(data.ratio)) {
      throw new Error('Format non supporté par ce modèle')
    }

    const costKey = `${data.durationSeconds}s_standard`
    const creditsCost = model.costPerGeneration[costKey] ?? 0
    if (creditsCost <= 0) throw new Error('Tarification indisponible pour cette configuration')

    const [generation] = await db
      .insert(videoGenerations)
      .values({
        userId: localUser.id,
        modelId: model.id,
        mode: data.mode,
        prompt: data.prompt,
        stylePreset: data.stylePreset,
        ratio: data.ratio,
        durationSeconds: data.durationSeconds,
        cameraControls: data.cameraControls ?? {},
        creditsCost,
        sourceGenerationId: data.sourceGenerationId,
      })
      .returning()

    const reserveIdempotencyKey = `video-reserve-${generation.id}`

    try {
      await reserveCredits({
        userId: localUser.id,
        amount: creditsCost,
        reason: 'video',
        referenceType: 'video_generation',
        referenceId: generation.id,
        idempotencyKey: reserveIdempotencyKey,
      })
    } catch (err) {
      await db.delete(videoGenerations).where(eq(videoGenerations.id, generation.id))
      throw err
    }

    await db.update(videoGenerations).set({ creditsReserved: true }).where(eq(videoGenerations.id, generation.id))

    const [job] = await db
      .insert(videoJobs)
      .values({
        generationId: generation.id,
        status: 'queued',
        idempotencyKey: `video-job-${generation.id}`,
      })
      .returning()

    try {
      const { providerJobId } = await submitToVideoProvider({
        modelSlug: model.slug,
        mode: data.mode,
        prompt: data.prompt,
        ratio: data.ratio,
        durationSeconds: data.durationSeconds,
      })
      await db
        .update(videoJobs)
        .set({ status: 'processing', providerJobId, updatedAt: new Date() })
        .where(eq(videoJobs.id, job.id))
    } catch (err) {
      const message = err instanceof VideoProviderNotConfiguredError ? err.message : 'Erreur technique du fournisseur vidéo'
      await db
        .update(videoJobs)
        .set({ status: 'failed', statusMessage: message, updatedAt: new Date() })
        .where(eq(videoJobs.id, job.id))
      await releaseReservedCredits({
        userId: localUser.id,
        amount: creditsCost,
        reason: 'video',
        referenceType: 'video_generation',
        referenceId: generation.id,
        idempotencyKey: `video-release-${generation.id}`,
      })
    }

    return { generationId: generation.id, jobId: job.id }
  })

export const getMyVideoGenerations = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context!.user)
    const generations = await db.query.videoGenerations.findMany({
      where: eq(videoGenerations.userId, localUser.id),
      orderBy: (g, { desc }) => desc(g.createdAt),
      limit: 50,
    })
    const jobs = await db.query.videoJobs.findMany()
    const jobByGeneration = new Map(jobs.map((j) => [j.generationId, j]))
    return generations.map((g) => ({ ...g, job: jobByGeneration.get(g.id) ?? null }))
  })
