import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'
import Anthropic from '@anthropic-ai/sdk'
import { db } from '../../db/index.js'
import { conversations, messages, apiUsage } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'
import { spendCredits, getBalance, InsufficientCreditsError } from './credits.js'

const CHAT_MODEL = 'claude-haiku-4-5'
const CHAT_COST_CREDITS = 2

export const getMyConversations = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    return db.query.conversations.findMany({
      where: eq(conversations.userId, localUser.id),
      orderBy: (c, { desc }) => desc(c.updatedAt),
    })
  })

export const getConversationMessages = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ conversationId: z.string().uuid() }))
  .handler(async ({ data }) => {
    return db.query.messages.findMany({
      where: eq(messages.conversationId, data.conversationId),
      orderBy: (m, { asc }) => asc(m.createdAt),
    })
  })

/**
 * Sends a message to Claude via Netlify's AI Gateway (zero-config on a deployed
 * Netlify site) and persists both sides of the exchange plus real usage/cost data.
 */
export const sendChatMessage = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(
    z.object({
      conversationId: z.string().uuid().optional(),
      content: z.string().min(1).max(8000),
    }),
  )
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)

    const { available } = await getBalance(localUser.id)
    if (available < CHAT_COST_CREDITS) throw new InsufficientCreditsError()

    let conversationId = data.conversationId
    if (!conversationId) {
      const [conv] = await db
        .insert(conversations)
        .values({ userId: localUser.id, title: data.content.slice(0, 60), model: CHAT_MODEL })
        .returning()
      conversationId = conv.id
    }

    await db.insert(messages).values({ conversationId, role: 'user', content: data.content })

    const history = await db.query.messages.findMany({
      where: eq(messages.conversationId, conversationId),
      orderBy: (m, { asc }) => asc(m.createdAt),
    })

    const anthropic = new Anthropic()
    const response = await anthropic.messages.create({
      model: CHAT_MODEL,
      max_tokens: 1024,
      messages: history.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
    })

    const block = response.content[0]
    const text = block && block.type === 'text' ? block.text : ''

    await db.insert(messages).values({ conversationId, role: 'assistant', content: text, model: CHAT_MODEL })
    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversationId))

    await spendCredits({
      userId: localUser.id,
      amount: CHAT_COST_CREDITS,
      reason: 'chat',
      referenceType: 'conversation',
      referenceId: conversationId,
      idempotencyKey: `chat-${conversationId}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    })

    await db.insert(apiUsage).values({
      userId: localUser.id,
      provider: 'anthropic',
      model: CHAT_MODEL,
      feature: 'chat',
      inputTokens: response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
    })

    return { conversationId, reply: text }
  })
