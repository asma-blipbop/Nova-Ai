import { createFileRoute } from '@tanstack/react-router'
import { LegalPage } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/remboursement')({ component: Page })

function Page() {
  return (
    <LegalPage title="Politique de remboursement">
      <p>Conformément au droit de la consommation français et européen, les consommateurs disposent d'un délai de rétractation de 14 jours pour les achats à distance, sauf lorsque l'exécution du service a commencé avec leur accord exprès et qu'ils ont renoncé à leur droit de rétractation pour un contenu numérique fourni immédiatement (ex: crédits déjà consommés).</p>
      <p>Chaque demande est examinée individuellement depuis la page Facturation : sélectionne le paiement concerné, indique le motif, et un administrateur traite la demande (remboursement total, partiel, ou refus motivé).</p>
      <p>NOVA AI ne se prévaut jamais d'une politique de "remboursement impossible" de manière systématique — chaque situation (erreur de facturation, échec technique de génération, double débit) fait l'objet d'un examen conforme aux règles impératives applicables aux consommateurs.</p>
      <p>En cas d'erreur technique avérée d'un fournisseur IA (génération échouée après débit), les crédits réservés sont automatiquement restitués — voir le fonctionnement décrit dans NOVA VIDEO.</p>
    </LegalPage>
  )
}
