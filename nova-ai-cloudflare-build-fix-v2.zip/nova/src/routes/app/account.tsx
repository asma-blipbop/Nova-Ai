import { createFileRoute, redirect } from '@tanstack/react-router'
import { User } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { useIdentity } from '../../lib/identity-context'

export const Route = createFileRoute('/app/account')({
  component: AccountPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

function AccountPage() {
  const { user, logout } = useIdentity()

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <User size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">Compte</h1>
        </div>
        <div className="nova-card p-6 space-y-4 mb-6">
          <div>
            <p className="text-xs text-nova-text-dim">Nom</p>
            <p>{user?.name || '—'}</p>
          </div>
          <div>
            <p className="text-xs text-nova-text-dim">Email</p>
            <p>{user?.email}</p>
          </div>
        </div>
        <div className="nova-card p-6 space-y-3">
          <button onClick={() => logout()} className="text-sm text-red-400 hover:underline">Se déconnecter</button>
          <p className="text-xs text-nova-text-dim">
            Pour supprimer ton compte ou exporter tes données personnelles (RGPD), écris à l'adresse indiquée sur la
            page Contact — la suppression et l'export sont traités manuellement pour garantir l'exactitude des données
            liées à la facturation.
          </p>
        </div>
      </div>
    </AppShell>
  )
}
