import {
  pgTable,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  numeric,
  uuid,
  index,
} from 'drizzle-orm/pg-core'

// ---------------------------------------------------------------------------
// Users & profile
// ---------------------------------------------------------------------------

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  identityId: text('identity_id').notNull().unique(), // Netlify Identity user id
  email: text('email').notNull().unique(),
  name: text('name'),
  role: text('role').notNull().default('user'), // user | admin
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const profiles = pgTable('profiles', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id).unique(),
  avatarUrl: text('avatar_url'),
  locale: text('locale').default('fr'),
  timezone: text('timezone').default('Europe/Paris'),
  marketingOptIn: boolean('marketing_opt_in').default(false),
  memoryEnabled: boolean('memory_enabled').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// ---------------------------------------------------------------------------
// Plans & subscriptions
// ---------------------------------------------------------------------------

export const plans = pgTable('plans', {
  id: uuid('id').primaryKey().defaultRandom(),
  slug: text('slug').notNull().unique(), // free | plus | pro | ultra | enterprise
  name: text('name').notNull(),
  priceCents: integer('price_cents').notNull().default(0),
  currency: text('currency').notNull().default('EUR'),
  monthlyCredits: integer('monthly_credits').notNull().default(0),
  badge: text('badge'),
  features: jsonb('features').$type<string[]>().notNull().default([]),
  videoAccess: boolean('video_access').notNull().default(false),
  isActive: boolean('is_active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
})

export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  planId: uuid('plan_id').notNull().references(() => plans.id),
  status: text('status').notNull().default('active'), // active | past_due | cancelled | pending_payment
  currentPeriodStart: timestamp('current_period_start').defaultNow(),
  currentPeriodEnd: timestamp('current_period_end'),
  cancelAtPeriodEnd: boolean('cancel_at_period_end').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const promotions = pgTable('promotions', {
  id: uuid('id').primaryKey().defaultRandom(),
  code: text('code').notNull().unique(),
  description: text('description'),
  percentOff: integer('percent_off').notNull(),
  durationMonths: integer('duration_months').notNull().default(1),
  active: boolean('active').notNull().default(false),
  startsAt: timestamp('starts_at'),
  endsAt: timestamp('ends_at'),
})

// ---------------------------------------------------------------------------
// Credits ledger
// ---------------------------------------------------------------------------

export const creditBalances = pgTable('credit_balances', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id).unique(),
  balance: integer('balance').notNull().default(0),
  reserved: integer('reserved').notNull().default(0), // credits held for in-flight jobs
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const creditTransactions = pgTable(
  'credit_transactions',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').notNull().references(() => users.id),
    type: text('type').notNull(), // grant | purchase | reserve | capture | release | refund | adjustment
    amount: integer('amount').notNull(), // positive = credit, negative = debit
    balanceAfter: integer('balance_after').notNull(),
    reason: text('reason').notNull(), // chat | search | doc | image | video | subscription | pack | admin
    referenceType: text('reference_type'), // video_job | image_generation | payment | ...
    referenceId: uuid('reference_id'),
    idempotencyKey: text('idempotency_key').notNull().unique(),
    metadata: jsonb('metadata'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [index('credit_tx_user_idx').on(t.userId)],
)

export const creditPacks = pgTable('credit_packs', {
  id: uuid('id').primaryKey().defaultRandom(),
  credits: integer('credits').notNull(),
  priceCents: integer('price_cents').notNull(),
  currency: text('currency').notNull().default('EUR'),
  active: boolean('active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
})

// ---------------------------------------------------------------------------
// Conversations / chat
// ---------------------------------------------------------------------------

export const conversations = pgTable('conversations', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  title: text('title').notNull().default('Nouvelle conversation'),
  model: text('model'),
  shareToken: text('share_token').unique(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const messages = pgTable(
  'messages',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    conversationId: uuid('conversation_id').notNull().references(() => conversations.id),
    role: text('role').notNull(), // user | assistant | system
    content: text('content').notNull(),
    model: text('model'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [index('messages_conversation_idx').on(t.conversationId)],
)

export const files = pgTable('files', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  conversationId: uuid('conversation_id').references(() => conversations.id),
  blobKey: text('blob_key').notNull(),
  fileName: text('file_name').notNull(),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  kind: text('kind').notNull(), // document | image | video_source
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// ---------------------------------------------------------------------------
// Web search
// ---------------------------------------------------------------------------

export const webSearches = pgTable('web_searches', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  query: text('query').notNull(),
  answer: text('answer'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const webSources = pgTable('web_sources', {
  id: uuid('id').primaryKey().defaultRandom(),
  searchId: uuid('search_id').notNull().references(() => webSearches.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  snippet: text('snippet'),
})

// ---------------------------------------------------------------------------
// Image generation
// ---------------------------------------------------------------------------

export const imageGenerations = pgTable('image_generations', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  provider: text('provider').notNull(),
  model: text('model').notNull(),
  prompt: text('prompt').notNull(),
  ratio: text('ratio').notNull().default('1:1'),
  style: text('style'),
  status: text('status').notNull().default('queued'), // queued | processing | completed | failed
  resultBlobKeys: jsonb('result_blob_keys').$type<string[]>().default([]),
  creditsCost: integer('credits_cost').notNull().default(0),
  error: text('error'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  completedAt: timestamp('completed_at'),
})

// ---------------------------------------------------------------------------
// NOVA VIDEO — providers, models, generations, jobs
// ---------------------------------------------------------------------------

export const videoProviders = pgTable('video_providers', {
  id: uuid('id').primaryKey().defaultRandom(),
  slug: text('slug').notNull().unique(), // e.g. "runway", "luma", "kling"
  name: text('name').notNull(),
  apiBaseUrl: text('api_base_url'),
  apiKeyEnvVar: text('api_key_env_var').notNull(), // name of the env var holding the secret, never the value
  webhookSecretEnvVar: text('webhook_secret_env_var'),
  enabled: boolean('enabled').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const videoModels = pgTable('video_models', {
  id: uuid('id').primaryKey().defaultRandom(),
  providerId: uuid('provider_id').notNull().references(() => videoProviders.id),
  slug: text('slug').notNull().unique(), // e.g. "nova-video-fast"
  name: text('name').notNull(),
  description: text('description'),
  supportsTextToVideo: boolean('supports_text_to_video').notNull().default(true),
  supportsImageToVideo: boolean('supports_image_to_video').notNull().default(false),
  supportedDurationsSeconds: jsonb('supported_durations_seconds').$type<number[]>().notNull().default([]),
  supportedRatios: jsonb('supported_ratios').$type<string[]>().notNull().default([]),
  supportedResolutions: jsonb('supported_resolutions').$type<string[]>().notNull().default([]),
  maxQueueSize: integer('max_queue_size').notNull().default(10),
  costPerGeneration: jsonb('cost_per_generation').$type<Record<string, number>>().notNull().default({}), // key `${duration}_${quality}` -> credits
  enabled: boolean('enabled').notNull().default(false),
  sortOrder: integer('sort_order').notNull().default(0),
})

export const videoGenerations = pgTable(
  'video_generations',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').notNull().references(() => users.id),
    modelId: uuid('model_id').notNull().references(() => videoModels.id),
    mode: text('mode').notNull(), // text_to_video | image_to_video | variation
    prompt: text('prompt').notNull(),
    enhancedPrompt: text('enhanced_prompt'),
    sourceImageBlobKey: text('source_image_blob_key'),
    sourceGenerationId: uuid('source_generation_id'),
    stylePreset: text('style_preset'),
    ratio: text('ratio').notNull(),
    durationSeconds: integer('duration_seconds').notNull(),
    resolution: text('resolution'),
    cameraControls: jsonb('camera_controls').$type<Record<string, unknown>>().default({}),
    creditsCost: integer('credits_cost').notNull(),
    creditsReserved: boolean('credits_reserved').notNull().default(false),
    creditsCaptured: boolean('credits_captured').notNull().default(false),
    resultBlobKey: text('result_blob_key'),
    thumbnailBlobKey: text('thumbnail_blob_key'),
    isFavorite: boolean('is_favorite').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [index('video_gen_user_idx').on(t.userId)],
)

export const videoJobs = pgTable(
  'video_jobs',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    generationId: uuid('generation_id').notNull().references(() => videoGenerations.id).unique(),
    providerJobId: text('provider_job_id'),
    status: text('status').notNull().default('queued'), // queued | processing | completed | failed | cancelled
    statusMessage: text('status_message'),
    attempts: integer('attempts').notNull().default(0),
    lastPolledAt: timestamp('last_polled_at'),
    webhookReceivedAt: timestamp('webhook_received_at'),
    idempotencyKey: text('idempotency_key').notNull().unique(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (t) => [index('video_jobs_status_idx').on(t.status)],
)

// ---------------------------------------------------------------------------
// Memory
// ---------------------------------------------------------------------------

export const memories = pgTable('memories', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  content: text('content').notNull(),
  source: text('source').notNull().default('manual'), // manual | auto
  enabled: boolean('enabled').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// ---------------------------------------------------------------------------
// API usage / cost tracking
// ---------------------------------------------------------------------------

export const apiUsage = pgTable('api_usage', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id),
  provider: text('provider').notNull(),
  model: text('model'),
  feature: text('feature').notNull(), // chat | search | image | video | docs | code
  inputTokens: integer('input_tokens').default(0),
  outputTokens: integer('output_tokens').default(0),
  estimatedCostCents: numeric('estimated_cost_cents', { precision: 10, scale: 4 }).default('0'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// ---------------------------------------------------------------------------
// Payments — Revolut Payment Links
// ---------------------------------------------------------------------------

export const revolutPaymentLinks = pgTable('revolut_payment_links', {
  id: uuid('id').primaryKey().defaultRandom(),
  target: text('target').notNull(), // plan:plus | plan:pro | plan:ultra | pack:<creditPackId>
  url: text('url').notNull(),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const payments = pgTable(
  'payments',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').notNull().references(() => users.id),
    target: text('target').notNull(), // plan:<slug> | pack:<id>
    amountCents: integer('amount_cents').notNull(),
    currency: text('currency').notNull().default('EUR'),
    provider: text('provider').notNull().default('revolut'),
    providerPaymentId: text('provider_payment_id'),
    status: text('status').notNull().default('pending'), // pending | confirmed | rejected | refunded
    confirmationMethod: text('confirmation_method'), // webhook | api | manual_admin
    confirmedByAdminId: uuid('confirmed_by_admin_id'),
    userNote: text('user_note'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    confirmedAt: timestamp('confirmed_at'),
  },
  (t) => [index('payments_status_idx').on(t.status)],
)

export const invoices = pgTable('invoices', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  paymentId: uuid('payment_id').notNull().references(() => payments.id),
  number: text('number').notNull().unique(),
  amountCents: integer('amount_cents').notNull(),
  taxCents: integer('tax_cents').notNull().default(0),
  currency: text('currency').notNull().default('EUR'),
  issuerLegalName: text('issuer_legal_name'),
  issuerAddress: text('issuer_address'),
  issuerVatNumber: text('issuer_vat_number'),
  issuedAt: timestamp('issued_at').defaultNow().notNull(),
})

export const refunds = pgTable('refunds', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  paymentId: uuid('payment_id').notNull().references(() => payments.id),
  reason: text('reason').notNull(),
  requestedAmountCents: integer('requested_amount_cents').notNull(),
  approvedAmountCents: integer('approved_amount_cents'),
  status: text('status').notNull().default('requested'), // requested | approved | rejected | paid
  adminNotes: text('admin_notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  resolvedAt: timestamp('resolved_at'),
})

// ---------------------------------------------------------------------------
// Admin & notifications
// ---------------------------------------------------------------------------

export const adminLogs = pgTable('admin_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  adminUserId: uuid('admin_user_id').notNull().references(() => users.id),
  action: text('action').notNull(),
  targetType: text('target_type'),
  targetId: text('target_id'),
  details: jsonb('details'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const notifications = pgTable('notifications', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  type: text('type').notNull(), // video_completed | payment_confirmed | refund_status | system
  title: text('title').notNull(),
  body: text('body'),
  readAt: timestamp('read_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})
