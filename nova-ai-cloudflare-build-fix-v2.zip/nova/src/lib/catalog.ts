import { db } from '../../db/index.js'
import { plans, creditPacks } from '../../db/schema.js'

/**
 * Ensures default plans and credit packs exist so pricing pages are never empty.
 * All values here are examples the admin can edit in the database — nothing is
 * hardcoded into the UI itself.
 */
export async function ensureDefaultCatalog() {
  const existingPlans = await db.query.plans.findMany()
  if (existingPlans.length === 0) {
    await db.insert(plans).values([
      {
        slug: 'free',
        name: 'Free',
        priceCents: 0,
        monthlyCredits: 150,
        features: ['Chat', 'Modèle rapide', 'Recherche limitée', 'Images limitées'],
        videoAccess: false,
        sortOrder: 0,
      },
      {
        slug: 'plus',
        name: 'Plus',
        priceCents: 799,
        monthlyCredits: 3000,
        features: ['Tout Free', 'Modèles avancés', 'Recherche illimitée', 'Images HD'],
        videoAccess: false,
        sortOrder: 1,
      },
      {
        slug: 'pro',
        name: 'Pro',
        priceCents: 1999,
        monthlyCredits: 12000,
        badge: '🔥 Le plus populaire',
        features: ['Tout Plus', 'NOVA VIDEO standard', 'Priorité de file', 'Support prioritaire'],
        videoAccess: true,
        sortOrder: 2,
      },
      {
        slug: 'ultra',
        name: 'Ultra',
        priceCents: 3999,
        monthlyCredits: 40000,
        features: ['Tout Pro', 'NOVA VIDEO avancée', 'Résolutions maximales', 'Support dédié'],
        videoAccess: true,
        sortOrder: 3,
      },
      {
        slug: 'enterprise',
        name: 'Enterprise',
        priceCents: 0,
        monthlyCredits: 0,
        features: ['Volumes personnalisés', 'SLA', 'Facturation dédiée', 'Account manager'],
        videoAccess: true,
        sortOrder: 4,
      },
    ])
  }

  const existingPacks = await db.query.creditPacks.findMany()
  if (existingPacks.length === 0) {
    await db.insert(creditPacks).values([
      { credits: 1000, priceCents: 499, sortOrder: 0 },
      { credits: 5000, priceCents: 1499, sortOrder: 1 },
      { credits: 15000, priceCents: 3499, sortOrder: 2 },
      { credits: 50000, priceCents: 7999, sortOrder: 3 },
    ])
  }

  return {
    plans: await db.query.plans.findMany({ orderBy: (p, { asc }) => asc(p.sortOrder) }),
    packs: await db.query.creditPacks.findMany({ orderBy: (p, { asc }) => asc(p.sortOrder) }),
  }
}
