import { createFileRoute, redirect } from '@tanstack/react-router'
import { LibraryBig, Play } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { getMyVideoGenerations } from '../../lib/video-actions'

export const Route = createFileRoute('/app/library')({
  component: LibraryPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
  loader: () => getMyVideoGenerations(),
})

function LibraryPage() {
  const generations = Route.useLoaderData()

  return (
    <AppShell>
      <div className="max-w-5xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <LibraryBig size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">Bibliothèque</h1>
        </div>
        <p className="text-sm text-nova-text-dim mb-6">Toutes tes créations NOVA VIDEO et NOVA IMAGE au même endroit.</p>
        {generations.length === 0 ? (
          <p className="text-sm text-nova-text-dim">Rien à afficher pour l'instant — lance ta première génération dans NOVA VIDEO.</p>
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
            {generations.map((g) => (
              <div key={g.id} className="nova-card p-3">
                <div className="aspect-video rounded-lg bg-nova-surface-2 border border-nova-border grid place-items-center mb-2 text-nova-text-dim">
                  <Play size={16} />
                </div>
                <p className="text-xs line-clamp-2">{g.prompt}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  )
}
