import { createFileRoute, redirect, Link } from '@tanstack/react-router'
import { Gem } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { getMyCreditData } from '../../lib/credit-actions'

export const Route = createFileRoute('/app/credits')({
  component: CreditsPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
  loader: () => getMyCreditData(),
})

const REASON_LABELS: Record<string, string> = {
  chat: 'Chat', search: 'Recherche', doc: 'Document', image: 'Image', video: 'Vidéo', code: 'Code',
  subscription: 'Abonnement', pack: 'Pack de crédits', admin: 'Ajustement admin',
}

function CreditsPage() {
  const { balance, transactions } = Route.useLoaderData()

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Gem size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Credits</h1>
        </div>
        <div className="nova-card p-6 mb-8 flex items-center justify-between">
          <div>
            <p className="text-3xl font-bold">{balance.available.toLocaleString('fr-FR')}</p>
            <p className="text-xs text-nova-text-dim">crédits disponibles {balance.reserved > 0 && `(${balance.reserved} réservés)`}</p>
          </div>
          <Link to="/pricing" className="nova-btn-primary rounded-lg px-4 py-2 text-sm">Acheter des crédits</Link>
        </div>
        <h2 className="font-semibold mb-3">Historique</h2>
        <div className="space-y-1">
          {transactions.length === 0 && <p className="text-sm text-nova-text-dim">Aucune transaction pour le moment.</p>}
          {transactions.map((t) => (
            <div key={t.id} className="flex items-center justify-between py-2.5 border-b border-nova-border text-sm">
              <div>
                <p>{REASON_LABELS[t.reason] ?? t.reason}</p>
                <p className="text-xs text-nova-text-dim">{new Date(t.createdAt).toLocaleString('fr-FR')}</p>
              </div>
              <p className={t.amount >= 0 ? 'text-nova-blue' : 'text-nova-text-dim'}>
                {t.amount >= 0 ? '+' : ''}{t.amount}
              </p>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
