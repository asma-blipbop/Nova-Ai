import { createFileRoute, useNavigate, Link } from '@tanstack/react-router'
import { useState } from 'react'
import { Sparkles } from 'lucide-react'
import { login, oauthLogin } from '@netlify/identity'
import { useIdentity } from '../lib/identity-context'

export const Route = createFileRoute('/login')({
  component: LoginPage,
})

function LoginPage() {
  const { user, ready } = useIdentity()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (ready && user) {
    navigate({ to: '/app/chat' })
    return null
  }

  async function handleLogin() {
    setError('')
    setLoading(true)
    try {
      await login(email, password)
      navigate({ to: '/app/chat' })
    } catch (err: any) {
      setError(err?.message ?? 'Connexion impossible')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen nova-noise flex items-center justify-center px-6">
      <div className="w-full max-w-sm nova-card p-8">
        <Link to="/" className="flex items-center gap-2 font-display font-semibold mb-8">
          <span className="grid place-items-center size-8 rounded-lg bg-gradient-to-br from-nova-violet to-nova-blue text-white">
            <Sparkles size={16} />
          </span>
          NOVA AI
        </Link>
        <h1 className="font-display text-xl font-bold mb-6">Connexion</h1>
        <div className="space-y-3">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Mot de passe"
            className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button onClick={handleLogin} disabled={loading} className="w-full nova-btn-primary rounded-lg py-2.5 text-sm">
            {loading ? 'Connexion…' : 'Se connecter'}
          </button>
          <button
            onClick={() => oauthLogin('google')}
            className="w-full border border-nova-border rounded-lg py-2.5 text-sm hover:bg-nova-surface-2"
          >
            Continuer avec Google
          </button>
        </div>
        <p className="text-xs text-nova-text-dim mt-6 text-center">
          Pas de compte ? <Link to="/signup" className="text-nova-violet-light">Créer un compte</Link>
        </p>
        <p className="text-[11px] text-nova-text-dim mt-4 text-center">
          Note : l'authentification Netlify Identity fonctionne uniquement une fois le site déployé (pas en local).
        </p>
      </div>
    </div>
  )
}
