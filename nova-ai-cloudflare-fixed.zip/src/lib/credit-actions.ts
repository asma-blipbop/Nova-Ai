import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { creditTransactions } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'
import { getBalance } from './credits.js'

export const getMyCreditData = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    const balance = await getBalance(localUser.id)
    const transactions = await db.query.creditTransactions.findMany({
      where: eq(creditTransactions.userId, localUser.id),
      orderBy: (t, { desc }) => desc(t.createdAt),
      limit: 50,
    })
    return { balance, transactions }
  })
