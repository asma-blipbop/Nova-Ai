import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { ShieldCheck, Users, TrendingUp, Video, AlertCircle } from 'lucide-react'
import { getServerUser } from '../lib/auth'
import { getAdminOverview, confirmPayment, rejectPayment, resolveRefund } from '../lib/admin-actions'

export const Route = createFileRoute('/admin')({
  component: AdminPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
    if (!user.roles?.includes('admin')) throw redirect({ to: '/app/chat' })
  },
  loader: () => getAdminOverview(),
})

function AdminPage() {
  const data = Route.useLoaderData()
  const [pending, setPending] = useState(data.pendingPayments)
  const [refunds, setRefunds] = useState(data.openRefunds)

  async function handleConfirm(id: string) {
    await confirmPayment({ data: { paymentId: id } })
    setPending((prev) => prev.filter((p) => p.id !== id))
  }
  async function handleReject(id: string) {
    await rejectPayment({ data: { paymentId: id } })
    setPending((prev) => prev.filter((p) => p.id !== id))
  }
  async function handleRefund(id: string, decision: 'approved' | 'rejected') {
    await resolveRefund({ data: { refundId: id, decision } })
    setRefunds((prev) => prev.filter((r) => r.id !== id))
  }

  return (
    <div className="min-h-screen bg-nova-black px-6 py-10">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-2 mb-8">
          <ShieldCheck size={22} className="text-nova-violet-light" />
          <h1 className="font-display text-2xl font-bold">Admin — NOVA AI</h1>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <Stat icon={Users} label="Utilisateurs" value={data.userCount} />
          <Stat icon={TrendingUp} label="Revenus confirmés" value={`${(data.confirmedRevenueCents / 100).toFixed(2)} €`} />
          <Stat icon={Video} label="Générations vidéo" value={data.videoCount} />
          <Stat icon={AlertCircle} label="Abonnements actifs" value={data.activeSubscriptions} />
        </div>

        <section className="mb-10">
          <h2 className="font-semibold mb-4">Paiements en attente ({pending.length})</h2>
          <div className="space-y-2">
            {pending.length === 0 && <p className="text-sm text-nova-text-dim">Aucun paiement en attente.</p>}
            {pending.map((p) => (
              <div key={p.id} className="nova-card p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm">{p.target} — {(p.amountCents / 100).toFixed(2)} € — utilisateur {p.userId.slice(0, 8)}</p>
                  <p className="text-xs text-nova-text-dim">{new Date(p.createdAt).toLocaleString('fr-FR')}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleConfirm(p.id)} className="text-xs px-3 py-1.5 rounded-lg nova-btn-primary">Confirmer</button>
                  <button onClick={() => handleReject(p.id)} className="text-xs px-3 py-1.5 rounded-lg border border-nova-border">Refuser</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-10">
          <h2 className="font-semibold mb-4">Remboursements en attente ({refunds.length})</h2>
          <div className="space-y-2">
            {refunds.length === 0 && <p className="text-sm text-nova-text-dim">Aucune demande en attente.</p>}
            {refunds.map((r) => (
              <div key={r.id} className="nova-card p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm">{r.reason}</p>
                  <p className="text-xs text-nova-text-dim">{(r.requestedAmountCents / 100).toFixed(2)} € demandés</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleRefund(r.id, 'approved')} className="text-xs px-3 py-1.5 rounded-lg nova-btn-primary">Accepter</button>
                  <button onClick={() => handleRefund(r.id, 'rejected')} className="text-xs px-3 py-1.5 rounded-lg border border-nova-border">Refuser</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="font-semibold mb-4">Fournisseurs & modèles vidéo</h2>
          <p className="text-sm text-nova-text-dim mb-4">
            Aucun fournisseur n'est activé tant qu'il n'y a pas de ligne dans <code className="text-xs">video_providers</code> avec
            <code className="text-xs"> enabled = true</code> et une clé API présente dans les variables d'environnement du site.
          </p>
          {data.videoProviders.length === 0 ? (
            <p className="text-sm text-amber-300">Aucun fournisseur vidéo enregistré.</p>
          ) : (
            <div className="space-y-2">
              {data.videoProviders.map((p) => (
                <div key={p.id} className="nova-card p-4 text-sm">
                  {p.name} — {p.enabled ? '✅ activé' : '⏸️ désactivé'} — clé attendue: <code className="text-xs">{p.apiKeyEnvVar}</code>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  )
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="nova-card p-5">
      <Icon size={18} className="text-nova-violet-light mb-3" />
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs text-nova-text-dim">{label}</p>
    </div>
  )
}
