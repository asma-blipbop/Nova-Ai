import { createFileRoute } from '@tanstack/react-router'
import { LegalPage, CompanyPlaceholder } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/contact')({ component: Page })

function Page() {
  return (
    <LegalPage title="Contact">
      <p>Pour toute question sur ton compte, une facture, un remboursement ou l'exercice de tes droits RGPD :</p>
      <CompanyPlaceholder />
    </LegalPage>
  )
}
