import { createFileRoute } from '@tanstack/react-router'
import { LegalPage } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/cgu')({ component: Page })

function Page() {
  return (
    <LegalPage title="Conditions générales d'utilisation">
      <p>L'utilisation de NOVA AI implique l'acceptation des présentes conditions.</p>
      <p>NOVA AI orchestre des modèles d'intelligence artificielle fournis par des tiers (fournisseurs de chat, de recherche, d'image et de vidéo). NOVA AI n'est pas l'éditeur de ces modèles et applique les politiques d'usage de chaque fournisseur configuré, notamment pour les contenus sensibles, les personnes réelles et les usages abusifs.</p>
      <p>Chaque fonctionnalité n'est disponible que lorsque le fournisseur correspondant est réellement configuré par l'administrateur — aucune génération n'est simulée.</p>
      <p>L'utilisateur s'engage à ne pas utiliser le service à des fins illégales, à ne pas tenter de contourner les limites de crédits ou de rôle, et à respecter les droits des tiers sur le contenu généré.</p>
      <p>Le compte peut être suspendu en cas d'abus manifeste (spam, contournement de sécurité, fraude au paiement).</p>
    </LegalPage>
  )
}
