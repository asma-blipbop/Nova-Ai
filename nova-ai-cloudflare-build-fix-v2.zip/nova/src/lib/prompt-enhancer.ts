import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import Anthropic from '@anthropic-ai/sdk'
import { requireAuthMiddleware } from '../middleware/identity.js'

/**
 * Uses Netlify AI Gateway (Anthropic) to turn a short idea into a detailed
 * video generation prompt. This is a real model call, not a template fill-in —
 * it requires the Netlify AI Gateway to be available on the deployed site.
 */
export const enhanceVideoPrompt = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ idea: z.string().min(2).max(500) }))
  .handler(async ({ data }) => {
    const anthropic = new Anthropic()
    const message = await anthropic.messages.create({
      model: 'claude-haiku-4-5',
      max_tokens: 400,
      messages: [
        {
          role: 'user',
          content: `Tu es un directeur de la photographie IA. Transforme cette idée courte en un prompt détaillé pour un générateur vidéo IA, en français, en une seule phrase riche. Décris: sujet, environnement, lumière, mouvement de caméra, composition, ambiance, niveau de réalisme. Idée: "${data.idea}"`,
        },
      ],
    })
    const block = message.content[0]
    const text = block && block.type === 'text' ? block.text : ''
    return { enhancedPrompt: text.trim() }
  })
