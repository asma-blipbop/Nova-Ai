import { createFileRoute, redirect } from '@tanstack/react-router'
import { FileText } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { NotConfiguredPanel } from '../../components/NotConfiguredPanel'
import { getServerUser } from '../../lib/auth'

export const Route = createFileRoute('/app/docs')({
  component: DocsPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

function DocsPage() {
  return (
    <AppShell>
      <div className="max-w-3xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <FileText size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Docs</h1>
        </div>
        <p className="text-sm text-nova-text-dim mb-6">
          Importe un PDF, DOCX, XLSX, PPTX, TXT, CSV ou une image pour un résumé, des questions, de l'extraction, une
          comparaison ou une traduction. L'upload nécessite un espace de stockage objet connecté.
        </p>
        <div className="border border-dashed border-nova-border rounded-xl p-10 text-center text-sm text-nova-text-dim mb-6">
          Dépose un fichier ici
        </div>
        <NotConfiguredPanel
          title="Stockage de fichiers non configuré"
          detail="Connecte Netlify Blobs (ou un stockage S3 compatible) pour activer l'upload et l'analyse de documents."
        />
      </div>
    </AppShell>
  )
}
