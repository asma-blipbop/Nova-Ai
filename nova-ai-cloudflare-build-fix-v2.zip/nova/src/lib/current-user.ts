import { eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { users, profiles, creditBalances } from '../../db/schema.js'
import type { User as IdentityUser } from '@netlify/identity'

/** Resolves (and lazily creates) the local `users` row for a Netlify Identity user. */
export async function getOrCreateLocalUser(identityUser: IdentityUser) {
  const existing = await db.query.users.findFirst({ where: eq(users.identityId, identityUser.id) })
  if (existing) return existing

  const email = identityUser.email ?? ''
  if (!email) throw new Error('Compte utilisateur sans adresse e-mail')

  const [created] = await db
    .insert(users)
    .values({
      identityId: identityUser.id,
      email,
      name: identityUser.name || email.split('@')[0],
    })
    .returning()

  await db.insert(profiles).values({ userId: created.id })
  await db.insert(creditBalances).values({ userId: created.id, balance: 150 })

  return created
}
