import { createServerFn } from '@tanstack/react-start'
import { eq, sql } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import {
  users,
  payments,
  refunds,
  subscriptions,
  videoGenerations,
  imageGenerations,
  webSearches,
  plans,
} from '../../db/schema.js'
import { requireRoleMiddleware } from '../middleware/identity.js'
import { grantCredits } from './credits.js'
import { getOrCreateLocalUser } from './current-user.js'

export const getAdminOverview = createServerFn({ method: 'GET' })
  .middleware([requireRoleMiddleware('admin')])
  .handler(async () => {
    const [userCount] = await db.select({ count: sql<number>`count(*)::int` }).from(users)
    const [confirmedRevenue] = await db
      .select({ total: sql<number>`coalesce(sum(${payments.amountCents}), 0)::int` })
      .from(payments)
      .where(eq(payments.status, 'confirmed'))
    const pendingPayments = await db.query.payments.findMany({
      where: eq(payments.status, 'pending'),
      orderBy: (p, { desc }) => desc(p.createdAt),
    })
    const openRefunds = await db.query.refunds.findMany({
      where: eq(refunds.status, 'requested'),
      orderBy: (r, { desc }) => desc(r.createdAt),
    })
    const [videoCount] = await db.select({ count: sql<number>`count(*)::int` }).from(videoGenerations)
    const [imageCount] = await db.select({ count: sql<number>`count(*)::int` }).from(imageGenerations)
    const [searchCount] = await db.select({ count: sql<number>`count(*)::int` }).from(webSearches)
    const activeSubs = await db.select({ count: sql<number>`count(*)::int` }).from(subscriptions).where(eq(subscriptions.status, 'active'))
    const providers = await db.query.videoProviders.findMany()
    const models = await db.query.videoModels.findMany()

    return {
      userCount: userCount.count,
      confirmedRevenueCents: confirmedRevenue.total,
      pendingPayments,
      openRefunds,
      videoCount: videoCount.count,
      imageCount: imageCount.count,
      searchCount: searchCount.count,
      activeSubscriptions: activeSubs[0]?.count ?? 0,
      videoProviders: providers,
      videoModels: models,
    }
  })

export const confirmPayment = createServerFn({ method: 'POST' })
  .middleware([requireRoleMiddleware('admin')])
  .inputValidator(z.object({ paymentId: z.string().uuid() }))
  .handler(async ({ context, data }) => {
    const admin = await getOrCreateLocalUser(context!.user)
    const payment = await db.query.payments.findFirst({ where: eq(payments.id, data.paymentId) })
    if (!payment) throw new Error('Paiement introuvable')
    if (payment.status === 'confirmed') return payment // idempotent — never double-credit

    const [updated] = await db
      .update(payments)
      .set({ status: 'confirmed', confirmationMethod: 'manual_admin', confirmedByAdminId: admin.id, confirmedAt: new Date() })
      .where(eq(payments.id, payment.id))
      .returning()

    if (payment.target.startsWith('pack:')) {
      // credits granted based on the pack's real credit amount at confirmation time
      const packId = payment.target.split(':')[1]
      const pack = await db.query.creditPacks.findFirst({ where: (p, { eq }) => eq(p.id, packId) })
      if (pack) {
        await grantCredits({
          userId: payment.userId,
          amount: pack.credits,
          reason: 'purchase',
          referenceType: 'payment',
          referenceId: payment.id,
          idempotencyKey: `pack-grant-${payment.id}`,
        })
      }
    } else if (payment.target.startsWith('plan:')) {
      const slug = payment.target.split(':')[1]
      const plan = await db.query.plans.findFirst({ where: eq(plans.slug, slug) })
      if (plan) {
        await db.insert(subscriptions).values({ userId: payment.userId, planId: plan.id, status: 'active' })
        await grantCredits({
          userId: payment.userId,
          amount: plan.monthlyCredits,
          reason: 'subscription',
          referenceType: 'payment',
          referenceId: payment.id,
          idempotencyKey: `sub-grant-${payment.id}`,
        })
      }
    }

    return updated
  })

export const rejectPayment = createServerFn({ method: 'POST' })
  .middleware([requireRoleMiddleware('admin')])
  .inputValidator(z.object({ paymentId: z.string().uuid() }))
  .handler(async ({ data }) => {
    await db.update(payments).set({ status: 'rejected' }).where(eq(payments.id, data.paymentId))
  })

export const resolveRefund = createServerFn({ method: 'POST' })
  .middleware([requireRoleMiddleware('admin')])
  .inputValidator(z.object({ refundId: z.string().uuid(), decision: z.enum(['approved', 'rejected']), approvedAmountCents: z.number().int().optional(), adminNotes: z.string().max(1000).optional() }))
  .handler(async ({ data }) => {
    await db
      .update(refunds)
      .set({ status: data.decision, approvedAmountCents: data.approvedAmountCents, adminNotes: data.adminNotes, resolvedAt: new Date() })
      .where(eq(refunds.id, data.refundId))
  })
