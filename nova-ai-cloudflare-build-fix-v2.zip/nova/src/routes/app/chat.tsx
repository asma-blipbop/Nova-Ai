import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { Send, Loader2, MessageSquare } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { sendChatMessage, getMyConversations } from '../../lib/chat-actions'

export const Route = createFileRoute('/app/chat')({
  component: ChatPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
  loader: () => getMyConversations(),
})

type ChatMessage = { role: 'user' | 'assistant'; content: string }

function ChatPage() {
  const conversations = Route.useLoaderData()
  const [conversationId, setConversationId] = useState<string | undefined>(conversations[0]?.id)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')

  async function handleSend() {
    if (!input.trim()) return
    const content = input
    setInput('')
    setChatMessages((prev) => [...prev, { role: 'user', content }])
    setSending(true)
    setError('')
    try {
      const res = await sendChatMessage({ data: { conversationId, content } })
      setConversationId(res.conversationId)
      setChatMessages((prev) => [...prev, { role: 'assistant', content: res.reply }])
    } catch (err: any) {
      setError(err?.message ?? 'Erreur lors de la génération de la réponse.')
    } finally {
      setSending(false)
    }
  }

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto h-screen flex flex-col py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <MessageSquare size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Chat</h1>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 mb-4">
          {chatMessages.length === 0 && (
            <p className="text-sm text-nova-text-dim">
              Pose une question — les réponses sont générées en direct via Netlify AI Gateway (Claude).
            </p>
          )}
          {chatMessages.map((m, i) => (
            <div key={i} className={`nova-card p-4 text-sm leading-relaxed whitespace-pre-wrap ${m.role === 'user' ? 'bg-nova-surface-2' : ''}`}>
              <p className="text-[11px] uppercase tracking-wide text-nova-text-dim mb-1">{m.role === 'user' ? 'Toi' : 'NOVA'}</p>
              {m.content}
            </div>
          ))}
          {sending && (
            <div className="nova-card p-4 text-sm text-nova-text-dim flex items-center gap-2">
              <Loader2 size={14} className="animate-spin" /> NOVA réfléchit…
            </div>
          )}
          {error && <p className="text-sm text-red-400">{error}</p>}
        </div>

        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSend()
              }
            }}
            rows={1}
            placeholder="Écris ton message… (2 crédits par message)"
            className="flex-1 bg-nova-surface-2 border border-nova-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:border-nova-violet"
          />
          <button onClick={handleSend} disabled={sending || !input.trim()} className="nova-btn-primary rounded-xl p-3 disabled:opacity-40">
            <Send size={16} />
          </button>
        </div>
      </div>
    </AppShell>
  )
}
