import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { Receipt } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { getMyPayments } from '../../lib/payment-actions'
import { getMyRefunds, requestRefund } from '../../lib/refund-actions'

export const Route = createFileRoute('/app/billing')({
  component: BillingPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
  loader: async () => {
    const [payments, refunds] = await Promise.all([getMyPayments(), getMyRefunds()])
    return { payments, refunds }
  },
})

const STATUS_LABELS: Record<string, string> = {
  pending: '⏳ En attente de validation',
  confirmed: '✅ Confirmé',
  rejected: '❌ Rejeté',
  refunded: '↩️ Remboursé',
}

function BillingPage() {
  const { payments, refunds } = Route.useLoaderData()
  const [reasonByPayment, setReasonByPayment] = useState<Record<string, string>>({})
  const [refundedIds, setRefundedIds] = useState<Set<string>>(new Set(refunds.map((r) => r.paymentId)))

  async function handleRefund(paymentId: string) {
    const reason = reasonByPayment[paymentId]
    if (!reason?.trim()) return
    await requestRefund({ data: { paymentId, reason } })
    setRefundedIds((prev) => new Set(prev).add(paymentId))
  }

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Receipt size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">Facturation</h1>
        </div>
        <p className="text-sm text-nova-text-dim mb-6">
          Tes paiements Revolut, leur statut de confirmation, et tes demandes de remboursement.
        </p>
        <div className="space-y-3">
          {payments.length === 0 && <p className="text-sm text-nova-text-dim">Aucun paiement enregistré.</p>}
          {payments.map((p) => (
            <div key={p.id} className="nova-card p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium">{p.target} — {(p.amountCents / 100).toFixed(2)} €</p>
                <span className="text-xs text-nova-text-dim">{STATUS_LABELS[p.status] ?? p.status}</span>
              </div>
              <p className="text-xs text-nova-text-dim mb-3">{new Date(p.createdAt).toLocaleString('fr-FR')}</p>
              {p.status === 'confirmed' && !refundedIds.has(p.id) && (
                <div className="flex gap-2">
                  <input
                    value={reasonByPayment[p.id] ?? ''}
                    onChange={(e) => setReasonByPayment((prev) => ({ ...prev, [p.id]: e.target.value }))}
                    placeholder="Motif du remboursement"
                    className="flex-1 bg-nova-surface-2 border border-nova-border rounded-lg px-3 py-1.5 text-xs"
                  />
                  <button onClick={() => handleRefund(p.id)} className="text-xs px-3 py-1.5 rounded-lg border border-nova-border hover:bg-nova-surface-2">
                    Demander un remboursement
                  </button>
                </div>
              )}
              {refundedIds.has(p.id) && <p className="text-xs text-nova-blue">Demande de remboursement envoyée.</p>}
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
