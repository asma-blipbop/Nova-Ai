import { createServerFn } from '@tanstack/react-start'
import { eq, and } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { memories } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'

export const getMyMemories = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    return db.query.memories.findMany({
      where: eq(memories.userId, localUser.id),
      orderBy: (m, { desc }) => desc(m.createdAt),
    })
  })

export const addMemory = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ content: z.string().min(1).max(1000) }))
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    const [memory] = await db.insert(memories).values({ userId: localUser.id, content: data.content, source: 'manual' }).returning()
    return memory
  })

export const toggleMemory = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ id: z.string().uuid(), enabled: z.boolean() }))
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    await db.update(memories).set({ enabled: data.enabled }).where(and(eq(memories.id, data.id), eq(memories.userId, localUser.id)))
  })

export const deleteMemory = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ id: z.string().uuid() }))
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    await db.delete(memories).where(and(eq(memories.id, data.id), eq(memories.userId, localUser.id)))
  })
