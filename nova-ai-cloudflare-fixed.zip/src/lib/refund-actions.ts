import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { refunds, payments } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'

export const requestRefund = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(z.object({ paymentId: z.string().uuid(), reason: z.string().min(3).max(1000) }))
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    const payment = await db.query.payments.findFirst({ where: eq(payments.id, data.paymentId) })
    if (!payment || payment.userId !== localUser.id) throw new Error('Paiement introuvable')

    const [refund] = await db
      .insert(refunds)
      .values({
        userId: localUser.id,
        paymentId: payment.id,
        reason: data.reason,
        requestedAmountCents: payment.amountCents,
      })
      .returning()
    return refund
  })

export const getMyRefunds = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    return db.query.refunds.findMany({ where: eq(refunds.userId, localUser.id), orderBy: (r, { desc }) => desc(r.createdAt) })
  })
