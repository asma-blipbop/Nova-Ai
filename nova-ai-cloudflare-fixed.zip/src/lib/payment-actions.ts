import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { payments, revolutPaymentLinks } from '../../db/schema.js'
import { requireAuthMiddleware } from '../middleware/identity.js'
import { getOrCreateLocalUser } from './current-user.js'

export const getPaymentLink = createServerFn({ method: 'GET' })
  .inputValidator(z.object({ target: z.string() }))
  .handler(async ({ data }) => {
    const link = await db.query.revolutPaymentLinks.findFirst({
      where: eq(revolutPaymentLinks.target, data.target),
    })
    return link && link.active ? link.url : null
  })

/**
 * Records that a user says they paid via a Revolut Payment Link. A redirect back
 * from Revolut is never treated as proof of payment — this only creates a
 * "pending" record for manual admin review (or future webhook confirmation).
 */
export const recordPendingPayment = createServerFn({ method: 'POST' })
  .middleware([requireAuthMiddleware])
  .inputValidator(
    z.object({
      target: z.string(),
      amountCents: z.number().int().nonnegative(),
      userNote: z.string().max(500).optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    const [payment] = await db
      .insert(payments)
      .values({
        userId: localUser.id,
        target: data.target,
        amountCents: data.amountCents,
        status: 'pending',
        userNote: data.userNote,
      })
      .returning()
    return payment
  })

export const getMyPayments = createServerFn({ method: 'GET' })
  .middleware([requireAuthMiddleware])
  .handler(async ({ context }) => {
    const localUser = await getOrCreateLocalUser(context.user)
    return db.query.payments.findMany({
      where: eq(payments.userId, localUser.id),
      orderBy: (p, { desc }) => desc(p.createdAt),
    })
  })
