import { Link } from '@tanstack/react-router'
import { Sparkles } from 'lucide-react'
import { useIdentity } from '../lib/identity-context'

export function MarketingNav() {
  const { user, ready } = useIdentity()

  return (
    <header className="sticky top-0 z-50 nova-glass">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2 font-display font-semibold text-lg">
          <span className="grid place-items-center size-8 rounded-lg bg-gradient-to-br from-nova-violet to-nova-blue text-white">
            <Sparkles size={16} />
          </span>
          NOVA AI
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-nova-text-dim">
          <Link to="/video" className="hover:text-nova-text transition-colors">NOVA VIDEO</Link>
          <Link to="/pricing" className="hover:text-nova-text transition-colors">Tarifs</Link>
          <Link to="/legal/mentions-legales" className="hover:text-nova-text transition-colors">Légal</Link>
        </nav>
        <div className="flex items-center gap-3">
          {ready && user ? (
            <Link
              to="/app/chat"
              className="px-4 py-2 rounded-lg text-sm nova-btn-primary"
            >
              Ouvrir NOVA AI
            </Link>
          ) : (
            <>
              <Link to="/login" className="hidden sm:inline text-sm text-nova-text-dim hover:text-nova-text">
                Connexion
              </Link>
              <Link to="/signup" className="px-4 py-2 rounded-lg text-sm nova-btn-primary">
                ✨ Commencer gratuitement
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

export function MarketingFooter() {
  return (
    <footer className="border-t border-nova-border py-12 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div className="col-span-2">
          <div className="flex items-center gap-2 font-display font-semibold mb-3">
            <span className="grid place-items-center size-7 rounded-lg bg-gradient-to-br from-nova-violet to-nova-blue text-white">
              <Sparkles size={14} />
            </span>
            NOVA AI
          </div>
          <p className="text-nova-text-dim max-w-sm">Toute l'IA. Un seul espace.</p>
        </div>
        <div>
          <p className="font-medium mb-3">Produit</p>
          <ul className="space-y-2 text-nova-text-dim">
            <li><Link to="/video" className="hover:text-nova-text">NOVA VIDEO</Link></li>
            <li><Link to="/pricing" className="hover:text-nova-text">Tarifs</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-medium mb-3">Légal</p>
          <ul className="space-y-2 text-nova-text-dim">
            <li><Link to="/legal/mentions-legales" className="hover:text-nova-text">Mentions légales</Link></li>
            <li><Link to="/legal/cgu" className="hover:text-nova-text">CGU</Link></li>
            <li><Link to="/legal/cgv" className="hover:text-nova-text">CGV</Link></li>
            <li><Link to="/legal/confidentialite" className="hover:text-nova-text">Confidentialité</Link></li>
            <li><Link to="/legal/cookies" className="hover:text-nova-text">Cookies</Link></li>
            <li><Link to="/legal/remboursement" className="hover:text-nova-text">Remboursement</Link></li>
            <li><Link to="/legal/contact" className="hover:text-nova-text">Contact</Link></li>
          </ul>
        </div>
      </div>
      <p className="max-w-7xl mx-auto mt-10 text-xs text-nova-text-dim">
        &copy; {new Date().getFullYear()} NOVA AI. NOVA AI orchestre des modèles d'IA tiers configurés par l'administrateur — ce n'est pas un modèle propriétaire.
      </p>
    </footer>
  )
}
