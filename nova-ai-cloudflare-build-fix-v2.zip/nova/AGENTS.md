# AGENTS.md — NOVA AI

Notes d'architecture pour tout agent (humain ou IA) travaillant sur ce dépôt.

## Règle absolue : ne jamais simuler une fonctionnalité

C'est la contrainte la plus importante du projet. Aucun paiement, crédit, résultat de
génération vidéo/image, résultat de recherche ou modèle IA ne doit jamais être inventé
côté serveur ou côté client. Quand un fournisseur n'est pas configuré, l'UI affiche
`NotConfiguredPanel` ("Fournisseur non configuré") au lieu de données factices.

Cette règle est appliquée structurellement, pas seulement par convention :

- `src/lib/video-provider.ts` — `listEnabledVideoModels()` ne retourne un modèle vidéo
  que s'il est `enabled` en base **ET** que `process.env[apiKeyEnvVar]` résout à une
  vraie valeur. `submitToVideoProvider()` lève `VideoProviderNotConfiguredError` tant
  qu'aucun `case` fournisseur réel n'est branché.
- `src/lib/payment-actions.ts` / `src/lib/admin-actions.ts` — un clic sur un Revolut
  Payment Link n'est jamais considéré comme une preuve de paiement. Il crée seulement un
  `payments` en statut `pending`. Seul un admin humain (`confirmPayment`) peut le passer
  à `confirmed`, de façon idempotente (vérifie `status === 'confirmed'` avant tout effet).

## Grand livre de crédits (`src/lib/credits.ts`)

Toute mutation de solde passe par `creditTransactions`, une table append-only avec une
colonne `idempotencyKey` unique vérifiée en début de chaque fonction — impossible de
débiter/créditer deux fois la même opération.

- `reserveCredits` / `captureReservedCredits` / `releaseReservedCredits` — pour les
  actions asynchrones (job vidéo) : on réserve au moment de la soumission, on capture à
  la réussite, on libère à l'échec.
- `spendCredits` — débit direct pour une action instantanée (message de chat, exécution
  NOVA Code).
- `grantCredits` — ajout de crédits (achat de pack, abonnement, promo).

Ne jamais utiliser `grantCredits` avec un montant négatif pour débiter — utiliser
`spendCredits`, qui enregistre le bon `type` de transaction.

## Fournisseurs vidéo (`videoProviders` / `videoModels`)

`videoProviders.apiKeyEnvVar` stocke uniquement le **nom** d'une variable
d'environnement, jamais une clé en clair. Ajouter un nouveau fournisseur = ajouter une
ligne en base + un `case` dans `submitToVideoProvider()` + définir la variable d'env
correspondante sur Netlify.

## Base de données

Drizzle ORM avec Netlify Database (Postgres). Schéma unique dans `db/schema.ts`, client
dans `db/index.ts`. Après toute modification du schéma, régénérer une migration :
`npx drizzle-kit generate --name <nom>` (utiliser `drizzle-orm@beta` / `drizzle-kit@beta`,
pas `latest`).

## Authentification

Netlify Identity (`@netlify/identity`), pas de système d'auth maison. Les rôles
(`admin`) viennent de `app_metadata.roles` côté Netlify. Middlewares dans
`src/middleware/identity.ts` : `identityMiddleware`, `requireAuthMiddleware`,
`requireRoleMiddleware(role)`. L'auth ne fonctionne pas en local — seulement sur un
déploiement Netlify réel.

## Fonctions serveur

TanStack Start `createServerFn({ method })` avec `.inputValidator(zodSchema)` (pas
`.validator()`) et `.middleware([...])`. Toute validation de prix, de crédits ou de rôle
se fait côté serveur — jamais confiance dans une valeur envoyée par le client.

## Design system

Variables CSS et classes utilitaires dans `src/styles.css` (`.nova-glass`,
`.nova-card`, `.nova-glow-violet/blue`, `.nova-gradient-text`, `.nova-btn-primary`).
Ton visuel : dark premium, glassmorphism, accents violet/bleu néon — éviter la
surcharge décorative ("sapin de Noël").

## Pages légales

`src/components/LegalPage.tsx` fournit `CompanyPlaceholder`, un espace réservé explicite
pour les données réelles de l'entreprise (raison sociale, SIRET, adresse). Ne jamais
inventer de données légales réelles.
